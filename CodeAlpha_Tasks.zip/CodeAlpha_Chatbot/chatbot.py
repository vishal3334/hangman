"""
CodeAlpha Task 4: Basic Rule-Based Chatbot
Replies to simple inputs like "hello", "how are you", "bye".
"""

RESPONSES = {
    "hello": "Hi!",
    "hi": "Hello there!",
    "hey": "Hey! How can I help you?",
    "how are you": "I'm fine, thanks! How about you?",
    "what is your name": "I'm CodeBot, a simple Python chatbot.",
    "who made you": "I was created as a CodeAlpha internship project.",
    "help": "You can say: hello, how are you, what is your name, who made you, or bye.",
    "thanks": "You're welcome!",
    "thank you": "You're welcome!",
}


def get_reply(message):
    message = message.lower().strip().rstrip("?!.")
    if message in ("bye", "goodbye", "exit", "quit"):
        return "Goodbye!"
    if message in RESPONSES:
        return RESPONSES[message]
    for key, reply in RESPONSES.items():
        if key in message:
            return reply
    return "Sorry, I didn't understand that. Type 'help' to see what I can do."


def main():
    print("=== CODEBOT === (type 'bye' to exit)")
    while True:
        user = input("You: ")
        if not user.strip():
            continue
        reply = get_reply(user)
        print("Bot:", reply)
        if reply == "Goodbye!":
            break


if __name__ == "__main__":
    main()
