# CodeAlpha_Chatbot
Rule-based chatbot in Python (CodeAlpha Internship - Task 4).

- Replies to hello, how are you, bye and a few more inputs
- Concepts: if-elif, functions, loops, input/output

Run: `python chatbot.py`
